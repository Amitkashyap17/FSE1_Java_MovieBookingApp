import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import './Login.css';
//import Example3 from './ResetPassword';

const Login = () => {

  const navigate = useNavigate();

  const [credentials, setCredentials] = useState({
    loginId: '',
    password: '',
  });

  const handleChange = (event) => {
    setCredentials({ ...credentials, [event.target.name]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { loginId, password } = credentials;
    if (loginId) {
      axios.post('http://localhost:8080/api/v1.0/moviebooking/login', {
        loginId: loginId,
        password: password,
      })
        .then((response) => {
          console.log(response.data);
          // Handle success response here
          // Redirect to the addData page
          if (loginId === 'amit123') {
            navigate('admin');
          }
          else {
            navigate('user');
          }
        })
        .catch((error) => {
          console.error(error.response.data);
          // Handle error here
          //alert('Invalid login credentials');
          Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Oops! Something went wrong!',
            text: 'Invalid Login Credentials!',
            showConfirmButton: true,
            timer: 10000
          })
        });
    } else {
      // Handle the case when loginId is missing
      console.error('Login ID is required');
    }
  };

  return (
    <>
      <div className='header'><h2>Welcome to the Movie Booking App Portal!</h2></div>
      <div className='contaoner-fluid'>
        <div className="login-container">
          <div className="login-form">
            <form onSubmit={handleSubmit}>
              <h5 className='text-center' style={{ marginBottom: "20px" }}>Login Please!</h5>
              <div className="form-group">
                {/* <label htmlFor="loginId" style={{fontWeight:"normal"}}>LoginID</label> */}
                <input
                  type="text"
                  id="loginId"
                  name="loginId"
                  placeholder='Enter LoginID'
                  value={credentials.loginId}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <div className="form-group">
                {/* <label htmlFor="password" style={{fontWeight:"normal"}}>Password</label> */}
                <input
                  type="password"
                  id="password"
                  name="password"
                  placeholder='Enter Password'
                  value={credentials.password}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
                {/* <label htmlFor="forgot-password"><Link to="/ResetPassword">Forgot password?</Link></label> */}
              </div>
              <button type="submit" className="btn btn-primary">
                Continue
              </button>
              <div style={{ marginTop: 10 }}>
                <label htmlFor="register">Don't have an account?   <Link to="/register">Register</Link></label>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;