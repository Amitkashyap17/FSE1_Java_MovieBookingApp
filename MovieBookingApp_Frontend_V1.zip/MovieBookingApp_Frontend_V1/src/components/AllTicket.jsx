import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { Button, Nav, Navbar, Container } from 'react-bootstrap';
import { Table } from 'react-bootstrap';

const AllTicket = () => {

  const navigate = useNavigate();

  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = () => {
    axios
      .get('http://localhost:8080/api/v1.0/moviebooking/getallbookedticket', {
      })
      //localStorage.getItem(token)
      .then((response) => {
        setTickets(response.data);
        localStorage.setItem('AllTicket', response.data.accessToken)
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <>
      <div>
        <Navbar bg="dark" data-bs-theme="dark">
          <Container>
            <Navbar.Brand href="/admin">MovieBooking App</Navbar.Brand>
            <Nav className="me-auto">
              <Nav.Link href="/tickets">Booking</Nav.Link>
              <Nav.Link href="/movie">Movies</Nav.Link>
              <Link to="/"><Button variant='danger' style={{ marginLeft: 750 }} onClick={() => {
                localStorage.removeItem('token');
                navigate('/')
              }}>Logout</Button></Link>
            </Nav>
          </Container>
        </Navbar>
      </div>
      <div className="container">
        <div className='text-center'>
          <h3 style={{ marginTop: "10px", marginBottom: "20px" }}>Tickets List</h3>
        </div>
        <Table striped bordered hover variant="dark">
          <thead>
            <tr>
              <th>LoginId</th>
              <th>Movie Name</th>
              <th>Theatre Name</th>
              <th>Number of Tickets</th>
              <th>Seat Numbers</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map((ticket) => (
              <tr key={ticket.id}>
                <td>{ticket.loginId}</td>
                <td>{ticket.movieName}</td>
                <td>{ticket.theatreName}</td>
                <td>{ticket.noOfTickets}</td>
                <td>
                  {Array.isArray(ticket.seatNumber)
                    ? ticket.seatNumber.join(', ')
                    : 'N/A'}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
};

export default AllTicket;