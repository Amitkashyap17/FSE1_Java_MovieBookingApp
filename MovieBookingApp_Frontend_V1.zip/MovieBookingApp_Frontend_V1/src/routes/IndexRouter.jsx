import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AdminDashboard from '../components/AdminDashboard';
import UserDashboard from '../components/UserDashboard';
import Login from '../components/Login';
import Movies from '../components/Movies';
import AllTicket from '../components/AllTicket';
import BookTicket from '../components/BookTicket';
import MovieDelete from '../components/MovieDelete';
import Register from '../components/Register';
import ResetPassword from '../components/ResetPassword';

const IndexRouter = () => {
    return (
        <div>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="/user" element={<UserDashboard />} />
                <Route path="/movies" element={<Movies />} />
                <Route path="/tickets" element={<AllTicket />} />
                <Route path="/booking" element={<BookTicket />} />
                <Route path="/movie" element={<MovieDelete />} />
                <Route path="/register" element={<Register />} />
                <Route path="/reset" element={<ResetPassword />} />
            </Routes>
        </div>
    );
}

export default IndexRouter;