import React from 'react';
import { Nav, Navbar, Container, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import CarouselPage from './CarouselPage';
import './Login.css';

const UserDashboard = () => {

    const navigate = useNavigate();

    return (
        <>
            <Navbar bg="dark" data-bs-theme="dark">
                <Container>
                    <Navbar.Brand href="/user">MovieBooking App</Navbar.Brand>
                    <Nav className="me-auto">
                        <Nav.Link href="/movies">Movies</Nav.Link>
                        {/* <Nav.Link href="/user">User Dashboard!</Nav.Link> */}
                        <Link to="/"><Button variant='danger' style={{ marginLeft: 850 }} onClick={() => {
                            localStorage.removeItem('token');
                            navigate('/')
                        }}>Logout</Button></Link>
                    </Nav>
                </Container>
            </Navbar>
            <div className='header'><h2>Welcome to the User Dashboard!</h2></div>
            <div><CarouselPage /></div>
        </>
    )
}

export default UserDashboard;