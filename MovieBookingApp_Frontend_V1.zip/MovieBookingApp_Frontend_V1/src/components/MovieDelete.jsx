import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Nav, Navbar, Container, Button, Row, Col, Card } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import BookTicket from './BookTicket';

const MovieDelete = () => {

    const navigate = useNavigate();

    const [movies, setMovies] = useState([]);

    useEffect(() => {
        fetchMovies();
    }, []);

    const fetchMovies = async () => {
        try {
            const response = await axios.get('http://localhost:8080/api/v1.0/moviebooking/all'); // Replace with your backend API endpoint
            setMovies(response.data);
        } catch (error) {
            console.error(error);
            // Handle error, e.g., show an error message
        }
    };

    const deleteMovie = async (movieName) => {
        console.log(movieName);
        try {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then(async (result) => {
                if (result.isConfirmed) {
                    await axios.delete(`http://localhost:8080/api/v1.0/moviebooking/${movieName}/delete`); // Replace with your backend API endpoint
                    fetchMovies();
                    Swal.fire(
                        'Deleted!',
                        'Your file has been deleted.',
                        'success'
                    )
                }
            })
        } catch (error) {
            console.error(error);
            // Handle error, e.g., show an error message
        }
    };

    return (
        <>
            <div>
                <Navbar bg="dark" data-bs-theme="dark">
                    <Container>
                        <Navbar.Brand href="/admin">MovieBooking App</Navbar.Brand>
                        <Nav className="me-auto">
                            <Nav.Link href="/tickets">Booking</Nav.Link>
                            <Nav.Link href="/movie">Movies</Nav.Link>
                            <Link to="/"><Button variant='danger' style={{ marginLeft: 750 }} onClick={() => {
                                localStorage.removeItem('token');
                                navigate('/')
                            }}>Logout</Button></Link>
                        </Nav>
                    </Container>
                </Navbar>
            </div>
            <div className="container" style={{ marginBottom: 30 }}>
                <h4 className="text-left" style={{ marginBottom: 5, marginTop: 30 }}>NOW SHOWING</h4>
                <Row xs={3} md={4} className="g-2">
                    {movies.map((element, id) => (
                        <Col key={id}>
                            <Card>
                                <Link to="/AddTicket">
                                    <Card.Img style={{
                                        height: "326px",
                                        width: "272px"
                                    }} variant="top" src={element.poster} />
                                </Link>
                                <Card.Body>
                                    <Card.Title>{element.movieName}</Card.Title>
                                    <Card.Text>Theatre Name : {element.theatreName}</Card.Text>
                                    <Card.Text>Tickets Availbility : {element.noOfTicketsAvailable}</Card.Text>
                                    <Card.Text>Tickets Status : {element.ticketsStatus}</Card.Text>
                                    <Card.Text>
                                        <BookTicket />
                                        <Button
                                            variant="outline-danger"
                                            size="sm"
                                            type="submit"
                                            onClick={() => deleteMovie(element.movieName)}
                                            style={{ marginLeft: 30, borderRadius: 20, marginTop: 10 }}
                                        >
                                            DELETE
                                        </Button>
                                    </Card.Text>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </div>
        </>
    );
};

export default MovieDelete;