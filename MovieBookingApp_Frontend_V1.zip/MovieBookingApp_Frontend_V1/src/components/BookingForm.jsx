import React, { useState } from 'react';
import axios from 'axios';

const BookingForm = () => {
const [formData, setFormData] = useState({
    loginId:'',
movieName: '',
theatreName: '',
noOfTickets: 0,
seatNumber:[],
});

const handleChange = (e) => {
const { name, value } = e.target;
setFormData((prevData) => ({
...prevData,
[name]: value,
}));
};

const handleSubmit = (e) => {
e.preventDefault();
// API endpoint URL
const apiUrl = 'http://localhost:8080/api/v1.0/moviebooking/' + formData.movieName + '/add';

axios
.post(apiUrl, formData)
.then((response) => {
// Handle success response
console.log('Booking successful!', response.data);
})
.catch((error) => {
// Handle error
console.error('Error while booking:', error);
});
};

return (
<div>
<h2>Book Tickets</h2>
<form onSubmit={handleSubmit}>
<label>
loginId:
<input type="text" name="loginId" value={formData.loginId} onChange={handleChange} />
</label>
<label>
Movie Name:
<input type="text" name="movieName" value={formData.movieName} onChange={handleChange} />
</label>
<br />
<label>
theatreName:
<input type="text" name="theatreName" value={formData.theatreName} onChange={handleChange} />
</label>
<br />
<label>
Number of Tickets:
<input
type="number"
name="noOfTickets"
value={formData.noOfTickets}
onChange={handleChange}
/>
</label>
<label>
Seat Number:
<input
type="number"
name="seatNumber"
value={formData.seatNumber}
onChange={handleChange}
/>
</label>
<br />
<button type="submit">Book Tickets</button>
</form>
</div>
);
};

export default BookingForm;