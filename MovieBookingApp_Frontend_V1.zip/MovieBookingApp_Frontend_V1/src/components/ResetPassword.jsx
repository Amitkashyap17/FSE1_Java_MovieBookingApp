import axios from 'axios';
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';

function Example3() {

    const [credentials, setCredentials] = useState({
        loginId: '',
        password: '',
      });

      const handleChange = (event) => {
        setCredentials({ ...credentials, [event.target.name]: event.target.value });
      };

    // const handlePasswordChange = (event) => {
    //     setCredentials(event.target.value);
    // };

    const handleSubmit = (event) => {
        event.preventDefault();
        const { loginId, password } = credentials;
        axios
            .post('http://localhost:8080/api/v1.0/moviebooking/'+loginId+'/forgot', {
                loginId:loginId,
                password:password,
            })
            .then((response) => {
                console.log(response.data);
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: 'Great!',
                    text: 'Password has been changed successfully!',
                    showConfirmButton: true,
                    timer: 10000
                })
            })
            .catch((error) => {
                console.error(error.response.data);
                //setMessage('User not found.');
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Oops! Something went wrong!',
                    text: 'Invalid LoginID!',
                    showConfirmButton: true,
                    timer: 10000
                })
            });
    };

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    return (
        <>
            <label onClick={handleShow}>
                <Link style={{color:'rgb(193, 47, 96)'}}>Forgot Password?</Link>
            </label>
            <Modal show={show} onHide={handleClose} size="sm">
                <Modal.Header closeButton>
                    <Modal.Title>Reset Password</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {/* <div className="login-form"> */}
                        <form onSubmit={handleSubmit}>
                            <div className="form-group">
                                <label htmlFor="loginId" style={{fontWeight:"normal"}}>LoginID</label>
                                <input
                                    type="text"
                                    id="loginId"
                                    name="loginId"
                                    placeholder='Enter LoginID'
                                    value={credentials.loginId}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="newPassword" style={{fontWeight:"normal"}}>New Password</label>
                                <input
                                    type="password"
                                    id="password"
                                    name="password"
                                    placeholder='Enter New Password'
                                    value={credentials.password}
                                    onChange={handleChange}
                                    className="form-control"
                                    required
                                />
                            </div>
                            <button type="submit" className="btn btn-primary" style={{marginLeft:170}}>
                                Confirm
                            </button>
                        </form>
                </Modal.Body>
            </Modal>
        </>
    );
}

export default Example3;