import axios from 'axios';
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Swal from 'sweetalert2';
import './Login.css';

function BookTicket() {

  const [ticket, setTicket] = useState({
    loginId: '',
    movieName: '',
    theatreName: '',
    noOfTickets: 0,
    seatNumber: [],
  });
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "seatNumber") {
      const seatNumber = value.split(",").map((num) => num.trim()); // Split the input string and trim whitespace
      setTicket((prevTicket) => ({ ...prevTicket, [name]: seatNumber }));
    } else {
      setTicket((prevTicket) => ({ ...prevTicket, [name]: value }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post('http://localhost:8080/api/v1.0/moviebooking/' + ticket.movieName + '/add', ticket) // Replace with your backend API endpoint
      .then((response) => {
        console.log(response.data);
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Great!',
          text: 'Tickets booked successfully!',
          showConfirmButton: true,
          timer: 10000
        })
      })
      .catch((error) => {
        console.error(error);
        Swal.fire({
          position: 'center',
          icon: 'error',
          title: 'Oops... Something went wrong!',
          text: 'MovieName or TheatreName not found',
          showConfirmButton: true,
          timer: 10000
        })
        // alert("Please try again later");
        // Handle error, e.g., show an error message
      });


  };

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <Button className='text-center' onClick={handleShow} variant='outline-primary' size='sm' style={{ marginLeft: 15, marginTop: 10, borderRadius: 20 }}>BOOK TICKETS</Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Book Tickets</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="id">LoginId</label>
              <input
                type="text"
                className="form-control"
                id="loginId"
                name="loginId"
                value={ticket.loginId}
                onChange={handleChange}
                required />
            </div>
            <div className='row'>
              <div className='col-sm'>
                <div className="form-group">
                  <label htmlFor="movie">Movie Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="movieName"
                    name="movieName"
                    value={ticket.movieName}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className='col-sm'>
                <div className="form-group">
                  <label htmlFor="theatreName">Theatre Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="theatreName"
                    name="theatreName"
                    value={ticket.theatreName}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>
            <div className='row'>
              <div className='col-sm'>
                <div className="form-group">
                  <label htmlFor="numTickets">No. of Tickets</label>
                  <input
                    type="number"
                    className="form-control"
                    id="noOfTickets"
                    name="noOfTickets"
                    value={ticket.noOfTickets}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className='col-sm'>
                <div className="form-group">
                  <label htmlFor="seatNumbers">Seat Numbers</label>
                  <input
                    type="text"
                    className="form-control"
                    id="seatNumber"
                    name="seatNumber"
                    value={ticket.seatNumber}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>
            <div className='button-group'>
            <button type="submit" className="btn btn-primary">Confirm</button>
            </div>
          </form>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default BookTicket;