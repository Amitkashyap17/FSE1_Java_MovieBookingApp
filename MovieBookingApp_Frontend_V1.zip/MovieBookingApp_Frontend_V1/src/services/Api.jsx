import axios from "axios";

export const fetchApi = async (
  url,
  method,
  body,
  statusCode = 200,
  token = null,
  isFormData = false
) => {
  const BASE_URL = "http://localhost:8080/";

  try {
    let headers = {
      "Content-Type": isFormData ? "multipart/form-data" : "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
    };

    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }

    let response = await axios({
      headers: headers,
      baseURL: BASE_URL,
      method: method,
      crossDomain: true,
      url: url,
      timeout: 30000,
      data: body,
    });

    const result = {
      success: false,
      responseBody: null,
      responseHeaders: null,
    };

    if (response.status === statusCode) {
      result.success = true;
      result.responseBody = response.data;
      result.responseHeaders = response.headers;
    }
    return result;
  } catch (ex) {
    return ex;
  }
};
