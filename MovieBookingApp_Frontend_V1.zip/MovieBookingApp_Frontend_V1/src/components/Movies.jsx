import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Row, Col, Form, Button, Nav, Navbar, Container } from 'react-bootstrap';
import Swal from 'sweetalert2';
import { useNavigate, Link } from 'react-router-dom';
import BookTicket from './BookTicket';

const Movies = () => {

  const navigate = useNavigate();

  const [movies, setMovies] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchMovies();
  }, []);

  const handleSearch = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/api/v1.0/moviebooking/movies/search/${search}`);
      setMovies(response?.data);
    } catch (error) {
      console.error(error);
      navigate('/movies')
      Swal.fire({
        position: 'center',
        icon: 'error',
        title: 'Oops! Something went wrong!',
        text: 'Please enter a valid movie name',
        showConfirmButton: true,
        timer: 10000
      })
    }
  };

  const fetchMovies = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/v1.0/moviebooking/all'); // Replace with your backend API endpoint
      setMovies(response.data);
    } catch (error) {
      console.error(error);
      // Handle error, e.g., show an error message
    }
  };

  return (
    <>
      <div>
        <Navbar bg="dark" data-bs-theme="dark">
          <Container>
            <Navbar.Brand href="/user">MovieBooking App</Navbar.Brand>
            <Nav className="me-auto">
              <Nav.Link href="/movies">Movies</Nav.Link>
              {/* <Nav.Link href="/user">User Dashboard!</Nav.Link> */}
              <Link to="/"><Button variant='danger' style={{ marginLeft: 850 }} onClick={() => {
                localStorage.removeItem('token');
                navigate('/')
              }}>Logout</Button></Link>
            </Nav>
          </Container>
        </Navbar>
      </div>
      <div>
        <Form className="d-flex">
          <Form.Control
            type="search"
            placeholder="Search Movie"
            className="me-2 rounded-pill"
            aria-label="Search"
            value={search}
            style={{ width: "400px", height: "40px", marginLeft: "70px", marginTop: "20px" }}
            onChange={(e) => {
              setSearch(e.target.value);
              // setContent("");
            }}
          />
          <Button
            className="rounded-pill"
            style={{ width: "100px", height: "42px", marginTop: "20px" }}
            onClick={handleSearch}
            variant="info"
          >
            Search
          </Button>
        </Form>
      </div>
      <div className="container" style={{ marginBottom: 30 }}>
        <h4 className="text-left" style={{ marginBottom: 5, marginTop: 30 }}>NOW SHOWING</h4>
        <Row xs={3} md={4} className="g-2">
          {movies.map((element, id) => (
            <Col key={id}>
              <Card>
                {/* <Link to="/booking"> */}
                <Card.Img style={{
                  height: "326px",
                  width: "272px"
                }} variant="top" src={element.poster} />
                <Card.Body>
                  <Card.Title>{element.movieName}</Card.Title>
                  <Card.Text>Theatre Name : {element.theatreName}</Card.Text>
                  <Card.Text>Tickets Availbility : {element.noOfTicketsAvailable}</Card.Text>
                  <Card.Text>Tickets Status : {element.ticketsStatus}</Card.Text>
                  <div style={{ marginLeft: 50 }}>
                    <BookTicket />
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </div>
    </>
  );
};

export default Movies;