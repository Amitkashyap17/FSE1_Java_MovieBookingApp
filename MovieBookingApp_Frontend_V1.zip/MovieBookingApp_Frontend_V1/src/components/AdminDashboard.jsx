import React from 'react';
import { Nav, Navbar, Container, Button } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import CarouselPage from './CarouselPage';
import './Login.css';

const AdminDashboard = () => {

    const navigate = useNavigate();
    return (
        <>
            <Navbar bg="dark" data-bs-theme="dark">
                <Container>
                    <Navbar.Brand href="/admin">MovieBooking App</Navbar.Brand>
                    <Nav className="me-auto">
                        <Nav.Link href="/tickets">Booking</Nav.Link>
                        <Nav.Link href="/movie">Movies</Nav.Link>
                        <Link to="/"><Button variant='danger' style={{ marginLeft: 750 }} onClick={() => {
                            localStorage.removeItem('token');
                            navigate('/')
                        }}>Logout</Button></Link>
                    </Nav>
                </Container>
            </Navbar>
            <div className='header'><h2>Welcome to the Admin Dashboard!</h2></div>
            <div><CarouselPage /></div>
        </>
    )
}

export default AdminDashboard;